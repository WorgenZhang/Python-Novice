// Time:  O(1)
// Soace: O(1)

class Solution {
public:
    bool canWinNim(int n) {
        return n % 4 != 0;
    }
};
